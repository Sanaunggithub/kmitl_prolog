abstract class BaseLocalizations {
  BaseCommon get common;
  BaseNavigation get navigation;
  BaseSearch get search;
  BaseFavorites get favorites;
  BaseRouteResult get routeResult;
  BaseErrors get errors;
  BaseDirections get directions;
  BaseTransfers get transfers;
  BaseProximity get proximity;
  BaseSettings get settings;
  BaseJourney get journey;
  BaseAuth get auth;
  BaseUtility get utility;
}

abstract class BaseCommon {
  String get appTitle;
  String get cancelBtn;
  String get saveBtn;
  String get minutesUnit;
  String get secondsUnit;
  String get currencyUnit;
  String get kmUnit;
  String get metersUnit;
  String get total;
  String get laterBtn;
  String get errorOccurred;
  String get peopleUnit;
  String get closeBtn;
  String get download;
  String get genericError;
  String get viewDetails;
  String minutesFormat(int mins);
}

abstract class BaseNavigation {
  String get utilityTitle;
  String get searchTitle;
  String get mapTitle;
  String get favoritesTitle;
  String get settingsTitle;
}

abstract class BaseSearch {
  String get originLabel;
  String get destLabel;
  String get originHint;
  String get destHint;
  String get findRouteBtn;
  String get selectStationTitle;
  String get selectStationSubtitle;
  String get loadingStations;
  String get calculatingRoute;
  String get searchDesc;
  String get noStationFound;
  String get popularLandmark;
  String get customLocation;
  String get searchPlaceholder;
  String get useCurrentLocation;
  String get useCurrentLocationDesc;
  String get locationDeniedSnack;
  String get locationFailedSnack;
  String get groupStations;
  String get groupLandmarks;
  String get groupOtherTransit;
  String get groupPlaces;
  String showMore(int count);
  String get noResultsFound;
  String get clearAll;
  String get currentLocationNameTh;
  String get currentLocationNameEn;

  String get clearRoute;
  String get swapTooltip;
  String get resetNorthTooltip;
  String get fromPrefix;
  String get toPrefix;
  String get chooseDest;
  String get chooseOrigin;
}

abstract class BaseFavorites {
  String get emptyFavTitle;
  String get emptyFavSubtitle;
  String get emptyRouteTitle;
  String get emptyRouteSubtitle;
  String get setOriginBtn;
  String get setDestBtn;
  String get favStationsTab;
  String get favRoutesTab;
  String get stationAddedFav;
  String get stationRemovedFav;
  String get unnamedRoute;
}

abstract class BaseRouteResult {
  String get nextTrain;
  String get trainArriving;
  String get serviceEnded;
  String get crowdLevel;
  String get crowdLow;
  String get crowdMedium;
  String get crowdHigh;
  String get crowdUnknown;
  String get routeResultTitle;
  String get totalFare;
  String get totalTime;
  String get stationsCount;
  String get interchangeAt;
  String get saveRouteBtn;
  String get routeSavedSuccess;
  String get routeDeletedSuccess;
  String get linesCount;
  String get transfersCount;
  String get noRouteData;
  String get routeNameLabel;
  String get routeNameHint;
  String get fareTitle;
  String get routeRecommended;
  String get routeSaver;
  String get walkTo;
  String get fromLabel;
  String exitLabel(String exitCode);
  String get walkToStation;
  String get walkToDestination;
  String get cardDiscount;
  String get accuracyWarning;
  String get accuracyBody;
  String get reportIssueLink;
  String get reportDialogTitle;
  String get reportDialogBody;
  String get reportSuccess;
}

abstract class BaseErrors {
  String get errorSamePlaces;
  String get errorNoRoute;
  String errorFailed(String error);
  String get errorNoInternet;
}

abstract class BaseDirections {
  String get dirToKhuKhot;
  String get dirToKheha;
  String get dirToNationalStadium;
  String get dirToBangWa;
  String get dirToKrungThonBuri;
  String get dirToKhlongSan;
  String get dirCircleClockwise;
  String get dirCircleCounterClockwise;
  String get dirToKhlongBangPhai;
  String get dirToTaoPoon;
  String get dirToLatPhrao;
  String get dirToSamrong;
  String get dirToSuvarnabhumi;
  String get dirToPhayaThai;
  String get dirToMinBuri;
  String get dirToNonthaburiCivicCenter;
  String get dirToMuangThongThaniLake;
  String get dirToSiRatMuangThongThani;
  String get dirToRangsit;
  String get dirToKrungThepAphiwat;
  String get dirToTalingChan;
  String getDirectionLabel(String lineId, int boundIndex, String fallback);
}

abstract class BaseTransfers {
  String get transferThaphraUp;
  String get transferThaphraDown;
  String transferSiamSameLevel(int floor);
  String get transferSiamUp;
  String get transferSiamDown;
  String get transferLatphraoYellow;
  String get transferLatphraoBlue;
  String get transferPhayathai;
  String get transferSamrong;
  String get transferHuamak;
  String transferMakkasanPhetchaburi(String targetStation);
  String transferAsokSukhumvit(String targetStation);
  String transferSilomSaladaeng(String targetStation, String exitNum);
  String transferMoChitChatuchak(String targetStation, String exits);
  String interchangeWalk(int time);
  String interchangeLevels(int time);
  String transferSkywalk(String targetStation, int walkMins);
  String transferExit(String targetStation, String exitInfo, int walkMins);
  String transferPlatformLevel(String levelInfo, int walkMins);
  String transferGenericWalk(String targetStation, int walkMins);
}

abstract class BaseProximity {
  String get nearbyAlertTitle;
  String nearbyAlertBody(String stationName);
  String get nearestStationTitle;
  String nearestStationBody(String stationName, String distance);
  String get inAppNotifTitle;
  String inAppNotifBody(int count);
  String get interconnectText;
  String checkinSuccess(String stationName);
  String nearStationWalk(String stationName, String time);
  String promptDelayAtStation(String stationName);
  String get promptDelayBody;
  String get normalStatusLabel;
  String get yesDelayedLabel;
  String get thankYouReportLabel;
  String delayedAtStation(String name);
  String get detectedLonger;
}

abstract class BaseSettings {
  String get themeSetting;
  String get themeDark;
  String get themeLight;
  String get themeSystem;
  String get langSetting;
  String get langTh;
  String get langEn;
  String get aboutSetting;
  String get aboutDesc;
  String get versionInfo;
  String get locationPermissionRequired;
  String get locationPermissionDesc;
  String get openSettingsBtn;
  String get offlineMapTitle;
  String get offlineMapSubtitle;
  String get downloadDialogTitle;
  String get downloadDialogBody;
  String get downloadStarted;
  String get versionLabel;
  String get disclaimer;
  String get copyright;
  String get viewLicenses;
  String get offlineMapDownloading;
  String get offlineMapPreparing;
  String offlineMapDownloaded(int current, int total);
  String offlineMapCachedAndNew(int cached, int newCount);
  String prefetchProgress(String current, String total);
  String prefetchStats(String cached);
}

abstract class BaseJourney {
  String get startJourneyBtn;
  String get simulateJourneyBtn;
  String get endJourneyBtn;
  String get currentStationLabel;
  String get nextStationLabel;
  String get transferAtLabel;
  String get arrivedLabel;
  String get walkToLabel;
  String get simulationMode;
  String get nextSimulationBtn;
  String get stationsCount;
  String get walkingConnection;
  String get travelingStatus;
  String get walkingAction;
  String walkRemaining(String meters);
  String headingTo(String dest);
  String get transitRideAction;
  String etaRemaining(int minutes);
  String speedMeasure(String speed);
  String get arrivedText;
}

abstract class BaseUtility {
  String get statusSectionTitle;
  String get newsSectionTitle;
  String get noNewsAnnouncements;
  String get cardsSectionTitle;
  String get cardsSubtitle;
  String get rabbitCardName;
  String get mrtCardName;
  String get arlCardName;
  String get srtCardName;
  String get optionStandardTitle;
  String get optionStudentTitle;
  String get optionSeniorTitle;
  String get optionTripPackageTitle;
  String get optionStandardSubtitle;
  String get optionStudentBtsSubtitle;
  String get optionSeniorBtsSubtitle;
  String get optionTripPackageBtsSubtitle;
  String get optionStudentMrtSubtitle;
  String get optionSeniorMrtSubtitle;
  String get optionStudentArlSubtitle;
  String get optionSeniorArlSubtitle;
  String get optionStudentSrtSubtitle;
  String get optionSeniorSrtSubtitle;
  String get debugSimGpsTitle;
  String get debugSimGpsDisabled;
  String debugSimGpsActive(String lat, String lng);
  String get debugSimGpsDialogTitle;
  String get debugSimGpsDisableOption;
  String get debugSimGpsDisableSubtitle;
  String get debugSimGpsDisabledSnack;
  String debugSimGpsEnabledSnack(String stationName);
  String get officialAnnouncementTitle;
  String get reportDelayTitle;
  String get submitReportTitle;
  String get selectLineLabel;
  String get selectLineHint;
  String get selectStationLabel;
  String get selectLineFirstHint;
  String get selectStationHint;
  String get delayIntensityLabel;
  String get normalSmoothLabel;
  String get severeDelayLabel;
  String get submitReportBtn;
  String get errorLoadingStatus;
  String get reportSuccessSnack;
  String get lineBtsSukhumvit;
  String get lineBtsSilom;
  String get lineMrtBlue;
  String get lineMrtPurple;
  String get lineMrtYellow;
  String get lineMrtPink;
  String get lineArl;
  String get lineSrtRed;
  String get reportDelayDesc;
  String get fullClosure;
  String get partialClosure;
  String get minorDelay;
}

abstract class BaseAuth {
  String get loginTitle;
  String get registerTitle;
  String get emailLabel;
  String get emailHint;
  String get passwordLabel;
  String get passwordHint;
  String get confirmPasswordLabel;
  String get confirmPasswordHint;
  String get displayNameLabel;
  String get displayNameHint;
  String get loginBtn;
  String get registerBtn;
  String get googleLoginBtn;
  String get dontHaveAccount;
  String get alreadyHaveAccount;
  String get profileTitle;
  String get signOutBtn;
  String get signInToSync;
  String get signInToSyncDesc;
  String get invalidEmail;
  String get passwordTooShort;
  String get passwordsDoNotMatch;
  String get nameRequired;
  String get loginFailed;
  String get registrationFailed;
  String get syncSuccess;
  String get defaultUsername;
  String get orDivider;
}
