import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/router/route_constants.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/transit_colors.dart';
import '../../../models/station.dart';
import '../../../providers/providers.dart';
import '../../../widgets/shared/interchange_badges_row.dart';
import '../../../widgets/shared/station_badge.dart';
import '../../search/search_view_model.dart';

class NearestStationsSheet extends ConsumerWidget {
  final List<MapEntry<Station, double>> nearestEntries;
  final double accuracy;

  const NearestStationsSheet({
    super.key,
    required this.nearestEntries,
    required this.accuracy,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = ref.watch(translationsProvider);
    final localeCode = ref.watch(localeProvider);
    final theme = Theme.of(context);
    final searchVm = ref.read(searchViewModelProvider.notifier);
    final crowdRepo = ref.read(crowdRepositoryProvider);
    final transitRepo = ref.read(transitRepositoryProvider);

    return Container(
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Drag handle
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: theme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Header
          Text(
            t.search.selectStationTitle,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            t.search.selectStationSubtitle,
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 20),

          // List of Stations
          Flexible(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: nearestEntries.map((entry) {
                  final station = entry.key;
                  final distanceM = entry.value;

                  final lineColor = TransitColors.getLineColor(station.lineId);
                  final stationName = station.localizedName(localeCode);
                  final stationSubName = station.subName(localeCode);

                  // Format distance
                  final String distanceText;
                  if (distanceM >= 1000.0) {
                    final km = (distanceM / 1000.0).toStringAsFixed(1);
                    distanceText = '$km ${t.common.kmUnit}';
                  } else {
                    final m = distanceM.round();
                    distanceText = '$m ${t.common.metersUnit}';
                  }

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 2,
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      onTap: () async {
                        // 1. Passive check-in
                        await crowdRepo.reportPresence(
                          stationId: station.id,
                          accuracy: accuracy,
                        );

                        // 2. Set as origin in Search
                        searchVm.setOrigin(station);

                        if (context.mounted) {
                          // 3. Switch to Map tab (index 1) — search lives inside Map screen
                          context.go(AppRoute.map);
                          Navigator.pop(context); // Close bottom sheet

                          // 4. Show success banner
                          final msg = t.proximity.checkinSuccess(stationName);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(msg),
                              backgroundColor: theme.colorScheme.primary,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          );
                        }
                      },
                      leading: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: lineColor.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: StationBadge(
                            text: station.code,
                            lineId: station.lineId,
                            fontSize: 12,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                          ),
                        ),
                      ),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              stationName,
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Text(
                            distanceText,
                            style: TextStyle(
                              color: theme.colorScheme.primary,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            stationSubName,
                            style: theme.textTheme.bodyMedium?.copyWith(
                              fontSize: 12,
                            ),
                          ),
                          if (station.interchange.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            InterchangeBadgesRow(
                              interchangeStationIds: station.interchange,
                              transitRepo: transitRepo,
                              labelText: t.proximity.interconnectText,
                            ),
                          ],
                        ],
                      ),
                      trailing: Icon(
                        Icons.chevron_right_rounded,
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.4,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
