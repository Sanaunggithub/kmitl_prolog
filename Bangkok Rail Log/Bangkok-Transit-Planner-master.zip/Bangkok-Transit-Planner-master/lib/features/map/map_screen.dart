import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/router/route_constants.dart';
import 'dart:math' as math;
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_vector_tiles/flutter_map_vector_tiles.dart' as vt;
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/transit_colors.dart';
import '../../models/station.dart';
import '../../models/landmark.dart';
import '../../models/custom_location.dart';
import '../../models/namtang_stop.dart';
import '../../models/route_result.dart';
import '../../providers/providers.dart';
import '../search/search_view_model.dart';

import '../../core/constants/translation_helper.dart';
import 'widgets/map_overlay_stack.dart';
import 'painters/station_marker_painter.dart';
import 'painters/custom_map_pin.dart';
import '../route_result/route_result_sheet.dart';
import '../../providers/route_tracker.dart';
import 'package:bkk_transit_planner/core/utils/logger.dart';

class MapScreen extends ConsumerStatefulWidget {
  const MapScreen({super.key});

  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  final MapController _mapController = MapController();
  vt.Style? _lightStyle;
  vt.Style? _darkStyle;
  bool _isStylesLoading = true;
  Station? _selectedStation;
  CustomLocation? _customSelectedLocation;
  NamtangStop? _selectedNamtangStop;
  Position? _userPosition;
  bool _isLocating = false;
  bool _isPrefetchExpanded = true;
  final ValueNotifier<double> _currentZoom = ValueNotifier(12.0);
  final ValueNotifier<double> _currentRotation = ValueNotifier(0.0);

  // Caches for Map Layer Optimization
  List<Polyline> _cachedPolylines = [];
  RouteResult? _lastRouteResultForPolylines;
  Brightness? _lastBrightnessForPolylines;
  DisruptionState? _lastDisruptionStateForPolylines;

  List<Marker> _cachedBaseMarkers = [];
  RouteResult? _lastRouteResultForMarkers;
  Brightness? _lastBrightnessForMarkers;
  Brightness? _lastThemeBrightness;
  String? _lastCurrentStationId;
  double? _lastZoomForMarkers;
  DisruptionState? _lastDisruptionStateForMarkers;

  @override
  void initState() {
    super.initState();
    // Clear Flutter's memory image cache to force reloading fresh tiles
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    _fetchUserLocation();
    _loadVectorStyles();

    // Trigger Namtang stops loading when map is opened
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) ref.read(transitRepositoryProvider).loadNamtangStops();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        final routeResult = ref.read(searchViewModelProvider).routeResult;
        if (routeResult != null) {
          _fitRouteBounds(routeResult);
        }
        // Register listener once — not every build()
        ref.listenManual<SearchState>(searchViewModelProvider, (
          previous,
          next,
        ) {
          if (next.routeResult != null &&
              next.routeResult != previous?.routeResult) {
            _fitRouteBounds(next.routeResult!);
          }
        });
      }
    });
  }

  Future<void> _loadVectorStyles() async {
    if (!kIsWeb && Platform.environment.containsKey('FLUTTER_TEST')) {
      if (mounted) {
        setState(() {
          _isStylesLoading = false;
        });
      }
      return;
    }

    setState(() {
      _isStylesLoading = true;
    });

    try {
      final lightReader = vt.StyleReader(
        uri: 'https://tiles.openfreemap.org/styles/liberty',
      );
      final darkReader = vt.StyleReader(
        uri: 'https://tiles.openfreemap.org/styles/dark',
      );

      final loadedLight = await lightReader.read();
      final loadedDark = await darkReader.read();

      if (mounted) {
        setState(() {
          _lightStyle = loadedLight;
          _darkStyle = loadedDark;
          _isStylesLoading = false;
        });
      }
    } catch (e) {
      final isOfflineError = e.toString().contains('SocketException') ||
          e.toString().contains('Failed host lookup');
      if (isOfflineError) {
        AppLogger.info('Vector style loaded from offline cache');
      } else {
        AppLogger.error('Failed to load OpenFreeMap vector styles: $e', error: e);
      }
      if (mounted) {
        setState(() {
          _isStylesLoading = false;
        });
      }
    }
  }

  void _startMapPrefetch() {
    ref.read(mapPrefetchProvider.notifier).startPrefetch(1034);
    OfflineMapService.instance.downloadOrUpdate(
      onProgress: (current, total, progress) {
        ref.read(mapPrefetchProvider.notifier).updateProgress(
              current: current,
              success: current,
              cached: 0,
              error: 0,
            );
      },
      onComplete: (success, error) {
        ref.read(mapPrefetchProvider.notifier).finishPrefetch();
        ref.invalidate(offlineMapStatusProvider);
        if (mounted) {
          setState(() {});
          if (success) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Bangkok offline map download complete!'),
                behavior: SnackBarBehavior.floating,
              ),
            );
          } else if (error != null) {
            final t = ref.read(translationsProvider);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  error == 'No internet connection'
                      ? t.errors.errorNoInternet
                      : error,
                ),
                behavior: SnackBarBehavior.floating,
                backgroundColor: Colors.redAccent,
              ),
            );
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _lightStyle?.dispose();
    _darkStyle?.dispose();
    _mapController.dispose();
    _currentZoom.dispose();
    _currentRotation.dispose();
    super.dispose();
  }

  void _resetRotation() {
    _mapController.rotate(0.0);
    _currentRotation.value = 0.0;
  }

  void _fitRouteBounds(RouteResult routeResult) {
    final points = <LatLng>[];
    final originLat = routeResult.origin is Landmark
        ? (routeResult.origin as Landmark).routeLat
        : routeResult.origin.lat;
    final originLng = routeResult.origin is Landmark
        ? (routeResult.origin as Landmark).routeLng
        : routeResult.origin.lng;
    points.add(LatLng(originLat, originLng));

    final destLat = routeResult.destination is Landmark
        ? (routeResult.destination as Landmark).routeLat
        : routeResult.destination.lat;
    final destLng = routeResult.destination is Landmark
        ? (routeResult.destination as Landmark).routeLng
        : routeResult.destination.lng;
    points.add(LatLng(destLat, destLng));

    for (final segment in routeResult.segments) {
      if (segment.lineId == 'WALK' &&
          segment.walkingPath != null &&
          segment.walkingPath!.isNotEmpty) {
        points.addAll(segment.walkingPath!);
      } else {
        points.add(LatLng(segment.fromStation.lat, segment.fromStation.lng));
        points.add(LatLng(segment.toStation.lat, segment.toStation.lng));
        for (final s in segment.intermediateStations) {
          points.add(LatLng(s.lat, s.lng));
        }
      }
    }

    if (points.isEmpty) return;

    double minLat = 90.0;
    double maxLat = -90.0;
    double minLng = 180.0;
    double maxLng = -180.0;

    for (final p in points) {
      if (p.latitude < minLat) minLat = p.latitude;
      if (p.latitude > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }

    final bounds = LatLngBounds(LatLng(minLat, minLng), LatLng(maxLat, maxLng));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _mapController.fitCamera(
          CameraFit.bounds(
            bounds: bounds,
            padding: const EdgeInsets.only(
              left: 50.0,
              right: 50.0,
              top: 80.0,
              bottom: 260.0,
            ),
          ),
        );
      }
    });
  }

  Future<void> _fetchUserLocation() async {
    setState(() => _isLocating = true);
    try {
      final locationService = ref.read(locationServiceProvider);
      final hasMock = kDebugMode && ref.read(mockLocationProvider) != null;
      final hasPermission =
          hasMock || await locationService.isLocationPermissionGranted();
      if (hasPermission) {
        final pos = await locationService.getCurrentPosition();
        if (pos != null && mounted) {
          setState(() => _userPosition = pos);
        }
      }
    } catch (e) {
      AppLogger.error('Error fetching location: $e', error: e);
    } finally {
      if (mounted) {
        setState(() => _isLocating = false);
      }
    }
  }

  void _centerOnUser() {
    if (_userPosition != null) {
      _mapController.move(
        LatLng(_userPosition!.latitude, _userPosition!.longitude),
        14.0,
      );
    } else {
      _fetchUserLocation().then((_) {
        if (_userPosition != null) {
          _mapController.move(
            LatLng(_userPosition!.latitude, _userPosition!.longitude),
            14.0,
          );
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final t = ref.watch(translationsProvider);
    final transitRepo = ref.watch(transitRepositoryProvider);
    final routeResult = ref.watch(
      searchViewModelProvider.select((s) => s.routeResult),
    );
    final isRouteActive = routeResult != null;
    final localeCode = ref.watch(localeProvider);
    final isTrackingActive = ref.watch(
      routeTrackerProvider.select((s) => s.isActive),
    );
    final trackerState = isTrackingActive
        ? ref.watch(routeTrackerProvider)
        : null;
    final prefetchState = ref.watch(mapPrefetchProvider);
    final isCalculating = ref.watch(
      searchViewModelProvider.select((s) => s.isCalculating),
    );
    final disruptionState = ref.watch(disruptionProvider);

    // Build Polylines for transit lines
    final themeBrightness = theme.brightness;
    if (_lastThemeBrightness != null && _lastThemeBrightness != themeBrightness) {
      vt.VectorTileLayer.clearMemoryCache();
    }
    _lastThemeBrightness = themeBrightness;

    if (_lastRouteResultForPolylines != routeResult ||
        _lastBrightnessForPolylines != themeBrightness ||
        _lastDisruptionStateForPolylines != disruptionState) {
      _lastRouteResultForPolylines = routeResult;
      _lastBrightnessForPolylines = themeBrightness;
      _lastDisruptionStateForPolylines = disruptionState;
      final newPolylines = <Polyline>[];
      if (isRouteActive) {
        // Highlight ONLY the active route
        for (final segment in routeResult.segments) {
          final isWalk = segment.lineId == 'WALK';
          final points = <LatLng>[];
          if (isWalk &&
              segment.walkingPath != null &&
              segment.walkingPath!.isNotEmpty) {
            points.addAll(segment.walkingPath!);
          } else {
            points.add(
              LatLng(segment.fromStation.lat, segment.fromStation.lng),
            );
            for (final s in segment.intermediateStations) {
              points.add(LatLng(s.lat, s.lng));
            }
            points.add(LatLng(segment.toStation.lat, segment.toStation.lng));
          }

          newPolylines.add(
            Polyline(
              points: points,
              color: isWalk
                  ? Colors.grey
                  : TransitColors.getLineColor(segment.lineId),
              strokeWidth: isWalk ? 3.5 : 6.0,
              pattern: isWalk
                  ? const StrokePattern.dotted()
                  : const StrokePattern.solid(),
              borderColor: isWalk
                  ? Colors.transparent
                  : (themeBrightness == Brightness.dark
                        ? Colors.black.withValues(alpha: 0.3)
                        : Colors.white.withValues(alpha: 0.3)),
              borderStrokeWidth: isWalk ? 0.0 : 1.5,
            ),
          );
        }
      } else {
        // Show all lines
        for (final line in transitRepo.lines) {
          final points = line.stationIds.map((id) {
            final station = transitRepo.getStation(id);
            return LatLng(station!.lat, station.lng);
          }).toList();

          final lineDisruptions = disruptionState.getDisruptionsForLine(
            line.id,
          );
          final activeDisruption = lineDisruptions.isNotEmpty
              ? lineDisruptions.first
              : null;

          if (activeDisruption != null &&
              (activeDisruption.isFullClosure ||
                  activeDisruption.isPartialClosure)) {
            final alertColor = Colors.red.shade700;

            newPolylines.add(
              Polyline(
                points: points,
                color: alertColor,
                strokeWidth: 7.0,
                pattern: StrokePattern.dashed(segments: const [10, 6]),
                borderColor: themeBrightness == Brightness.dark
                    ? Colors.black.withValues(alpha: 0.5)
                    : Colors.white.withValues(alpha: 0.5),
                borderStrokeWidth: 1.5,
              ),
            );
          } else {
            newPolylines.add(
              Polyline(
                points: points,
                color: TransitColors.getLineColor(line.id),
                strokeWidth: 4.5,
                borderColor: themeBrightness == Brightness.dark
                    ? Colors.black.withValues(alpha: 0.3)
                    : Colors.white.withValues(alpha: 0.3),
                borderStrokeWidth: 1.0,
              ),
            );
          }
        }
      }
      _cachedPolylines = newPolylines;
    }
    final polylines = _cachedPolylines;

    // Build Station Markers
    final currentStationId = trackerState?.currentStation?.id;
    if (_lastRouteResultForMarkers != routeResult ||
        _lastBrightnessForMarkers != themeBrightness ||
        _lastCurrentStationId != currentStationId ||
        _lastZoomForMarkers != _currentZoom.value ||
        _lastDisruptionStateForMarkers != disruptionState) {
      _lastRouteResultForMarkers = routeResult;
      _lastBrightnessForMarkers = themeBrightness;
      _lastCurrentStationId = currentStationId;
      _lastZoomForMarkers = _currentZoom.value;
      _lastDisruptionStateForMarkers = disruptionState;
      final newMarkers = <Marker>[];

      if (isRouteActive) {
        // Find all transit stations on the route
        final routeStations = <Station>[];
        for (final segment in routeResult.segments) {
          if (segment.fromStation is Station) {
            final s = segment.fromStation as Station;
            if (!routeStations.any((x) => x.id == s.id)) routeStations.add(s);
          }
          for (final s in segment.intermediateStations) {
            if (!routeStations.any((x) => x.id == s.id)) routeStations.add(s);
          }
          if (segment.toStation is Station) {
            final s = segment.toStation as Station;
            if (!routeStations.any((x) => x.id == s.id)) routeStations.add(s);
          }
        }

        // Add markers for only these stations

        for (final station in routeStations) {
          final point = LatLng(station.lat, station.lng);

          final lineColor = TransitColors.getLineColor(station.lineId);
          final isInterchange = station.interchange.isNotEmpty;
          final isCurrentStation =
              isTrackingActive &&
              trackerState?.currentStation?.id == station.id;

          final double scale = (0.80 + (_currentZoom.value - 11.5) * 0.14)
              .clamp(0.80, 1.2);
          final double baseSize = isCurrentStation
              ? 44.0
              : (isInterchange ? 32.0 : 24.0);
          final double sizeValue = baseSize * scale;
          final disruption = disruptionState.getDisruptionForStation(
            station.id,
          );

          newMarkers.add(
            Marker(
              point: point,
              width: disruption != null ? sizeValue * 1.3 : sizeValue,
              height: disruption != null ? sizeValue * 1.3 : sizeValue,
              alignment: Alignment.center,
              child: RepaintBoundary(
                child: GestureDetector(
                  onTap: () {
                    setState(() => _selectedStation = station);
                  },
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(
                        size: Size(sizeValue, sizeValue),
                        painter: StationMarkerPainter(
                          lineColor: disruption != null
                              ? Colors.red.shade700
                              : lineColor,
                          isInterchange: isInterchange,
                          brightness: theme.brightness,
                          isCurrentStation: isCurrentStation,
                          scale: scale,
                        ),
                      ),
                      if (disruption != null)
                        Positioned(
                          right: -2,
                          top: -2,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: Colors.red.shade700,
                              shape: BoxShape.circle,
                              boxShadow: const [
                                BoxShadow(color: Colors.black38, blurRadius: 4),
                              ],
                            ),
                            child: const Icon(
                              Icons.warning_amber_rounded,
                              color: Colors.white,
                              size: 11,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }

        // Add Station Exit Markers
        for (final segment in routeResult.segments) {
          if (segment.lineId == 'WALK' && segment.exit != null) {
            // Exits are only shown at destination (where we walk from station: fromStation is Station), not at origin (where we walk to station: toStation is Station)
            if (segment.fromStation is! Station) continue;

            final exit = segment.exit!;
            final point = LatLng(exit.lat, exit.lng);

            newMarkers.add(
              Marker(
                point: point,
                width: 32,
                height: 32,
                alignment: Alignment.center,
                child: RepaintBoundary(
                  child: Tooltip(
                    message: t.routeResult.exitLabel(exit.exitCode),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.orange.shade800,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2.0),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          exit.exitCode,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          }
        }
      } else {
        // Show all stations
        for (final station in transitRepo.stations) {
          final point = LatLng(station.lat, station.lng);

          final lineColor = TransitColors.getLineColor(station.lineId);
          final isInterchange = station.interchange.isNotEmpty;
          final double scale = (0.80 + (_currentZoom.value - 11.5) * 0.14)
              .clamp(0.80, 1.2);
          final double sizeValue = (isInterchange ? 32.0 : 24.0) * scale;
          final disruption = disruptionState.getDisruptionForStation(
            station.id,
          );

          newMarkers.add(
            Marker(
              point: point,
              width: disruption != null ? sizeValue * 1.3 : sizeValue,
              height: disruption != null ? sizeValue * 1.3 : sizeValue,
              alignment: Alignment.center,
              child: RepaintBoundary(
                child: GestureDetector(
                  onTap: () {
                    setState(() => _selectedStation = station);
                  },
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(
                        size: Size(sizeValue, sizeValue),
                        painter: StationMarkerPainter(
                          lineColor: disruption != null
                              ? Colors.red.shade700
                              : lineColor,
                          isInterchange: isInterchange,
                          brightness: themeBrightness,
                          scale: scale,
                        ),
                      ),
                      if (disruption != null)
                        Positioned(
                          right: -2,
                          top: -2,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: Colors.red.shade700,
                              shape: BoxShape.circle,
                              boxShadow: const [
                                BoxShadow(color: Colors.black38, blurRadius: 4),
                              ],
                            ),
                            child: const Icon(
                              Icons.warning_amber_rounded,
                              color: Colors.white,
                              size: 11,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }
      }
      _cachedBaseMarkers = newMarkers;
    }

    final dynamicMarkers = <Marker>[];

    if (isRouteActive) {
      // Add custom origin/destination pins
      // Origin Pin (Green)
      final originLat = routeResult.origin.routeLat;
      final originLng = routeResult.origin.routeLng;
      dynamicMarkers.add(
        Marker(
          point: LatLng(originLat, originLng),
          width: 40,
          height: 44,
          alignment: Alignment.bottomCenter,
          child: RepaintBoundary(
            child: Tooltip(
              message: routeResult.origin.displayName(
                isEnglish: localeCode == 'en',
              ),
              child: CustomMapPin(
                color: Colors.green.shade600,
                icon: Icons.trip_origin_rounded,
              ),
            ),
          ),
        ),
      );

      // Destination Pin (Red)
      final destLat = routeResult.destination.routeLat;
      final destLng = routeResult.destination.routeLng;
      dynamicMarkers.add(
        Marker(
          point: LatLng(destLat, destLng),
          width: 40,
          height: 44,
          alignment: Alignment.bottomCenter,
          child: RepaintBoundary(
            child: Tooltip(
              message: routeResult.destination.displayName(
                isEnglish: localeCode == 'en',
              ),
              child: CustomMapPin(
                color: Colors.red.shade600,
                icon: Icons.flag_rounded,
              ),
            ),
          ),
        ),
      );

      // Add walking path direction markers
      for (final segment in routeResult.segments) {
        if (segment.lineId == 'WALK' &&
            segment.walkingPath != null &&
            segment.walkingPath!.isNotEmpty) {
          final path = segment.walkingPath!;
          for (int idx = 0; idx < path.length - 1; idx++) {
            final p1 = path[idx];
            final p2 = path[idx + 1];
            final dist = Geolocator.distanceBetween(
              p1.latitude,
              p1.longitude,
              p2.latitude,
              p2.longitude,
            );
            if (dist > 10.0) {
              final midpoint = LatLng(
                (p1.latitude + p2.latitude) / 2,
                (p1.longitude + p2.longitude) / 2,
              );

              // Calculate bearing in radians
              final lat1 = p1.latitude * math.pi / 180.0;
              final lon1 = p1.longitude * math.pi / 180.0;
              final lat2 = p2.latitude * math.pi / 180.0;
              final lon2 = p2.longitude * math.pi / 180.0;
              final dLon = lon2 - lon1;
              final y = math.sin(dLon) * math.cos(lat2);
              final x =
                  math.cos(lat1) * math.sin(lat2) -
                  math.sin(lat1) * math.cos(lat2) * math.cos(dLon);
              final bearing = math.atan2(y, x);

              dynamicMarkers.add(
                Marker(
                  point: midpoint,
                  width: 20,
                  height: 20,
                  alignment: Alignment.center,
                  child: RepaintBoundary(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          color: theme.brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: theme.brightness == Brightness.dark
                                ? Colors.white30
                                : Colors.black12,
                            width: 1.0,
                          ),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black12,
                              blurRadius: 2,
                              offset: Offset(0, 1),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Transform.rotate(
                            angle: bearing,
                            child: Icon(
                              Icons.arrow_upward_rounded,
                              size: 11,
                              color: theme.brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }
          }
        }
      }
    }

    // Add Namtang stops overlay when zoomed in
    // Optimization for mobile: Filter only visible markers within viewport
    // Zoom threshold: only show bus stops when zoomed in (>= 15.0) to avoid DOM overload in HTML renderer
    if (_currentZoom.value >= 15.0 && !isRouteActive) {
      try {
        final bounds = _mapController.camera.visibleBounds;
        for (final stop in transitRepo.namtangStops) {
          final stopPoint = LatLng(stop.lat, stop.lng);
          if (bounds.contains(stopPoint)) {
            dynamicMarkers.add(
              Marker(
                point: stopPoint,
                width: 24,
                height: 24,
                alignment: Alignment.center,
                child: RepaintBoundary(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedNamtangStop = stop;
                        _selectedStation = null;
                        _customSelectedLocation = null;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: themeBrightness == Brightness.dark
                            ? const Color(0xFF1E293B)
                            : Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: stop.type == 'boat'
                              ? Colors.blue.shade700
                              : (stop.type == 'commuter_train'
                                    ? Colors.red.shade700
                                    : Colors.green.shade700),
                          width: 2.0,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 4,
                            offset: Offset(0, 1),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Icon(
                          stop.type == 'boat'
                              ? Icons.directions_boat_rounded
                              : (stop.type == 'commuter_train'
                                    ? Icons.train_rounded
                                    : Icons.directions_bus_rounded),
                          size: 12,
                          color: stop.type == 'boat'
                              ? Colors.blue.shade700
                              : (stop.type == 'commuter_train'
                                    ? Colors.red.shade700
                                    : Colors.green.shade700),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          }
        }
      } catch (e) {
        AppLogger.error('Error rendering Namtang stops: $e', error: e);
      }
    }

    // User location marker
    if (_userPosition != null) {
      dynamicMarkers.add(
        Marker(
          point: LatLng(_userPosition!.latitude, _userPosition!.longitude),
          width: 24,
          height: 24,
          alignment: Alignment.center,
          child: RepaintBoundary(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Container(
                  width: 12,
                  height: 12,
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blueAccent,
                        blurRadius: 6,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    // Custom pinned location marker
    if (_customSelectedLocation != null) {
      dynamicMarkers.add(
        Marker(
          point: LatLng(
            _customSelectedLocation!.lat,
            _customSelectedLocation!.lng,
          ),
          width: 40,
          height: 44,
          alignment: Alignment.bottomCenter,
          child: RepaintBoundary(
            child: CustomMapPin(
              color: theme.colorScheme.primary,
              icon: Icons.push_pin_rounded,
            ),
          ),
        ),
      );
    }

    // Add Search Results
    final searchState = ref.watch(searchViewModelProvider);
    if (searchState.searchResults.isNotEmpty &&
        searchState.query.length >= 3 &&
        _selectedStation == null &&
        _customSelectedLocation == null) {
      for (final item in searchState.searchResults) {
        if (item is Landmark) {
          dynamicMarkers.add(
            Marker(
              point: LatLng(item.lat, item.lng),
              width: 32,
              height: 32,
              alignment: Alignment.center,
              child: const Icon(
                Icons.place_rounded,
                color: Colors.purple,
                size: 28,
              ),
            ),
          );
        }
      }
    }

    final isBottomCardVisible =
        _selectedStation != null ||
        _customSelectedLocation != null ||
        _selectedNamtangStop != null ||
        (isRouteActive && !isTrackingActive) ||
        isTrackingActive;

    final currentStyle =
        themeBrightness == Brightness.dark ? _darkStyle : _lightStyle;

    return Scaffold(
      body: Stack(
        children: [
          // Map Layer
          RepaintBoundary(
            child: ColoredBox(
              color: themeBrightness == Brightness.dark
                  ? const Color(0xFF1A1A2E)
                  : const Color(0xFFF2EFE9),
              child: ExcludeSemantics(
                child: FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    backgroundColor: themeBrightness == Brightness.dark
                        ? const Color(0xFF1A1A2E)
                        : const Color(0xFFF2EFE9),
                    initialCenter: const LatLng(13.7563, 100.5018),
                    initialZoom: 12.0,
                    minZoom: 10.5,
                    maxZoom: 19.0,
                    cameraConstraint: CameraConstraint.containCenter(
                      bounds: LatLngBounds(
                        const LatLng(13.20, 100.00),
                        const LatLng(14.25, 101.00),
                      ),
                    ),
                    onPositionChanged: (position, hasGesture) {
                      if ((position.zoom - _currentZoom.value).abs() > 0.05) {
                        setState(() {
                          _currentZoom.value = position.zoom;
                        });
                      }
                      if ((position.rotation - _currentRotation.value).abs() > 0.5) {
                        _currentRotation.value = position.rotation;
                      }
                    },
                    onTap: (position, point) {
                      if (_selectedStation != null) {
                        setState(() => _selectedStation = null);
                      }
                      if (_selectedNamtangStop != null) {
                        setState(() => _selectedNamtangStop = null);
                      }

                      final nearest = _findNearestStation(
                        point,
                        transitRepo.stations,
                      );
                      if (nearest != null) {
                        final dist = Geolocator.distanceBetween(
                          point.latitude,
                          point.longitude,
                          nearest.lat,
                          nearest.lng,
                        );
                        final walkMin = (dist / 80.0).clamp(1.0, 30.0);

                        setState(() {
                          _selectedStation = null;
                          _selectedNamtangStop = null;
                          _customSelectedLocation = CustomLocation(
                            id: 'CUSTOM_${point.latitude.toStringAsFixed(6)}_${point.longitude.toStringAsFixed(6)}',
                            nameTh:
                                '${t.search.customLocation} (${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)})',
                            nameEn:
                                '${t.search.customLocation} (${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)})',
                            nearestStationId: nearest.id,
                            walkingMinutes: walkMin,
                            lat: point.latitude,
                            lng: point.longitude,
                          );
                        });
                      }
                    },
                  ),
                  children: [
                    if (currentStyle != null)
                      vt.VectorTileLayer(
                        key: ValueKey('vector_tile_$themeBrightness'),
                        theme: currentStyle.theme,
                        tileProviders: currentStyle.providers,
                        sprites: currentStyle.sprites,
                        rasterSources: currentStyle.rasterSources,
                        tileOffset: vt.TileOffset.maplibre,
                        diskCacheMaximumSizeInBytes: 80 * 1024 * 1024,
                        diskCacheTtl: const Duration(days: 30),
                        showLabels: true,
                      ),
                    PolylineLayer(polylines: polylines),
                    MarkerLayer(markers: _cachedBaseMarkers),
                    MarkerLayer(markers: dynamicMarkers),
                  ],
                ),
              ),
            ),
          ),

          Positioned.fill(
            child: MapOverlayStack(
              mapLayer: const SizedBox.expand(),
              searchCard: Consumer(
                builder: (context, ref, child) {
                  final searchState = ref.watch(searchViewModelProvider);
                  return _buildTopSearchCard(
                    context,
                    searchState,
                    t,
                    localeCode,
                  );
                },
              ),
              prefetchState: prefetchState,
              theme: theme,
              t: t,
              localeCode: localeCode,
              isPrefetchExpanded: _isPrefetchExpanded,
              isLocating: _isLocating,
              isOfflineMapInitializing: _isStylesLoading,
              isBottomCardVisible: isBottomCardVisible,
              isCalculating: isCalculating,
              isTrackingActive: isTrackingActive,
              currentRotation: _currentRotation,
              onResetRotation: _resetRotation,
              selectedStation: _selectedStation,
              selectedLocation: _customSelectedLocation,
              selectedNamtangStop: _selectedNamtangStop,
              routeResult: routeResult,
              trackerState: trackerState,
              onTogglePrefetch: () =>
                  setState(() => _isPrefetchExpanded = !_isPrefetchExpanded),
              onStartPrefetch: _startMapPrefetch,
              onCenterOnUser: _centerOnUser,
              onCloseStation: () => setState(() => _selectedStation = null),
              onSelectHubStation: (station) =>
                  setState(() => _selectedStation = station),
              onSetOrigin: _setStationAsOrigin,
              onSetDestination: _setStationAsDestination,
              onCloseCustomLocation: () =>
                  setState(() => _customSelectedLocation = null),
              onOpenSearchOverlay: (focusDestination) => _openSearchOverlay(
                context,
                focusDestination: focusDestination,
              ),
              onCloseNamtangStop: () =>
                  setState(() => _selectedNamtangStop = null),
              onShowRouteDetail: () => _showRouteDetail(context),
            ),
          ),
        ],
      ),
    );
  }

  Station? _findNearestStation(LatLng point, List<Station> stations) {
    if (stations.isEmpty) return null;
    Station? closest;
    double minDist = double.infinity;
    for (final s in stations) {
      final dist = Geolocator.distanceBetween(
        point.latitude,
        point.longitude,
        s.lat,
        s.lng,
      );
      if (dist < minDist) {
        minDist = dist;
        closest = s;
      }
    }
    return closest;
  }

  Future<void> _setStationAsOrigin(Station station) async {
    await ref.read(searchViewModelProvider.notifier).setOrigin(station);
    if (!mounted) return;

    setState(() => _selectedStation = null);
    _openSearchOverlay(context, focusDestination: true);
  }

  Future<void> _setStationAsDestination(Station station) async {
    final hasOrigin = ref.read(searchViewModelProvider).origin != null;
    await ref.read(searchViewModelProvider.notifier).setDestination(station);
    if (!mounted) return;

    setState(() => _selectedStation = null);
    if (!hasOrigin) {
      _openSearchOverlay(context);
    }
  }

  void _showRouteDetail(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) => const RouteResultSheet(),
    );
  }

  Widget _buildTopSearchCard(
    BuildContext context,
    SearchState searchState,
    AppLocalizations t,
    String localeCode,
  ) {
    final theme = Theme.of(context);
    final hasOrigin = searchState.origin != null;
    final hasDest = searchState.destination != null;

    if (!hasOrigin && !hasDest) {
      return Hero(
        tag: 'search_bar_card',
        child: Card(
          elevation: 6,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: InkWell(
            onTap: () {
              _openSearchOverlay(context);
            },
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.search_rounded, color: theme.colorScheme.primary),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      t.search.searchPlaceholder,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    if (hasOrigin && hasDest) {
      return Hero(
        tag: 'search_bar_card',
        child: Card(
          elevation: 6,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.close_rounded),
                  tooltip: t.search.clearRoute,
                  onPressed: () {
                    ref.read(searchViewModelProvider.notifier).clear();
                  },
                ),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      _openSearchOverlay(context);
                    },
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.trip_origin_rounded,
                                color: Colors.green,
                                size: 14,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  searchState.origin!.displayName(
                                    isEnglish: localeCode == 'en',
                                  ),
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              const Icon(
                                Icons.location_on_rounded,
                                color: Colors.red,
                                size: 14,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  searchState.destination!.displayName(
                                    isEnglish: localeCode == 'en',
                                  ),
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.swap_vert_rounded,
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                  tooltip: t.search.swapTooltip,
                  onPressed: () {
                    ref.read(searchViewModelProvider.notifier).swapStations();
                  },
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Only one is set
    final setItem = hasOrigin ? searchState.origin : searchState.destination;
    final isOrigin = hasOrigin;

    return Hero(
      tag: 'search_bar_card',
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: InkWell(
          onTap: () {
            _openSearchOverlay(context, focusDestination: isOrigin);
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Icon(
                  isOrigin
                      ? Icons.trip_origin_rounded
                      : Icons.location_on_rounded,
                  color: isOrigin ? Colors.green : Colors.red,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    '${isOrigin ? t.search.fromPrefix : t.search.toPrefix} '
                    '${setItem!.displayName(isEnglish: localeCode == 'en')}',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  isOrigin ? t.search.chooseDest : t.search.chooseOrigin,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openSearchOverlay(
    BuildContext context, {
    bool focusDestination = false,
  }) {
    context.push(
      '${AppRoute.mapSearch}?${AppRoute.qFocusDest}=$focusDestination',
    );
  }
}
